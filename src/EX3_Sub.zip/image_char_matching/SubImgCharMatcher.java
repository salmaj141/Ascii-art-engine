
package image_char_matching;

import java.util.*;

/**
 * Matches characters to sub-image brightness values.
 * This class manages a set of characters, calculates their brightness levels,
 * and provides methods to find the character that best matches a given image brightness.
 * It supports adding and removing characters dynamically, re-normalizing brightness
 * values as the character set changes, and finding characters based on absolute
 * difference, rounding up, or rounding down.
 * @author salma,mariam
 */
public class SubImgCharMatcher {

    // A cache for the raw (unnormalized) brightness of characters.
    // This optimization prevents re-computing the brightness of a character
    // if it has already been calculated.
    private final Map<Character, Double> rawCharBrightness;

    // A map storing the normalized brightness values for the characters
    // currently in the 'charset'. These values are scaled between 0.0 and 1.0.
    private Map<Character, Double> normalizedCharBrightness;

    // A TreeSet to store the active set of characters.
    // TreeSet maintains characters in ascending ASCII order, which is crucial
    // for tie-breaking rules (lower ASCII value).
    private final TreeSet<Character> charset;

    // Stores the minimum raw brightness value among the characters in the current 'charset'.
    private double currentMinBrightness = -1;

    // Stores the maximum raw brightness value among the characters in the current 'charset'.
    private double currentMaxBrightness = -1;

    /**
     * Constructs a new SubImgCharMatcher with an initial set of characters.
     * The brightness values for these characters are computed and normalized upon initialization.
     *
     * @param initialCharset An array of characters to be used as the starting set.
     */
    public SubImgCharMatcher(char[] initialCharset) {
        this.rawCharBrightness = new HashMap<>();
        this.normalizedCharBrightness = new HashMap<>();
        this.charset = new TreeSet<>();
        for (char c : initialCharset) {
            addCharInternal(c, false);
        }
        normalizeCharBrightness();
    }

    /**
     * Adds a character to the set of characters used for matching.
     * If the character is already in the set, no action is taken.
     * If the character is new, its raw brightness is computed, and all character
     * brightnesses are re-normalized to reflect the change in the set's min/max brightness.
     *
     * @param c The character to add.
     */
    public void addChar(char c) {
        if (!charset.contains(c)) {
            addCharInternal(c, true);
        }
    }

    /**
     * Removes a character from the set of characters used for matching.
     * If the character is not in the set, no action is taken.
     * If the character is removed, all character brightnesses are re-normalized
     * to reflect the change in the set's min/max brightness.
     *
     * @param c The character to remove.
     */
    public void removeChar(char c) {
        if (charset.contains(c)) {
            charset.remove(c);
            rawCharBrightness.remove(c);
            normalizeCharBrightness();
        }
    }

    /**
     * Gets the character from the current set whose normalized brightness is closest
     * in absolute value to the given image brightness.
     * If multiple characters have the same minimal absolute difference, the one with the
     * lower ASCII value is returned (guaranteed by TreeSet iteration order).
     *
     * @param brightness The normalized brightness value of a sub-image (0.0 to 1.0).
     * @return The character from the set that best matches the given brightness.
     * Returns '?' if the character set is empty (though this case should ideally
     * be prevented by the calling code based on exercise requirements).
     */
    public char getCharByImageBrightness(double brightness) {
        char bestChar = '?';
        double bestDiff = Double.MAX_VALUE;
        for (Map.Entry<Character, Double> entry : normalizedCharBrightness.entrySet()) {
            double diff = Math.abs(entry.getValue() - brightness);
            if (diff < bestDiff || (diff == bestDiff && entry.getKey() < bestChar)) {
                bestDiff = diff;
                bestChar = entry.getKey();
            }
        }
        return bestChar;
    }

    /**
     * Gets the character from the current set whose normalized brightness is closest
     * to the given image brightness, by rounding up.
     * This means it finds the character with the smallest brightness value that is
     * greater than or equal to the given brightness.
     * If multiple characters satisfy the condition, the one with the lower ASCII value is returned.
     *
     * @param brightness The normalized brightness value of a sub-image (0.0 to 1.0).
     * @return The character from the set that best matches the brightness by rounding up.
     * Returns '?' if no such character is found or the set is empty.
     */
    public char getCharByImageBrightnessUp(double brightness) {
        char bestChar = '?';
        double bestCandidate = Double.MAX_VALUE;
        for (Map.Entry<Character, Double> entry : normalizedCharBrightness.entrySet()) {
            double b = entry.getValue();
            if (b >= brightness && b < bestCandidate) {
                bestCandidate = b;
                bestChar = entry.getKey();
            }
        }
        return bestChar;
    }

    /**
     * Gets the character from the current set whose normalized brightness is closest
     * to the given image brightness, by rounding down.
     * This means it finds the largest brightness value that is less than or equal
     * to the given brightness.
     * If multiple characters satisfy the condition, the one with the lower ASCII value is returned.
     *
     * @param brightness The normalized brightness value of a sub-image (0.0 to 1.0).
     * @return The character from the set that best matches the brightness by rounding down.
     * Returns '?' if no such character is found or the set is empty.
     */
    public char getCharByImageBrightnessDown(double brightness) {
        char bestChar = '?';
        double bestCandidate = -1;
        for (Map.Entry<Character, Double> entry : normalizedCharBrightness.entrySet()) {
            double b = entry.getValue();
            if (b <= brightness && b > bestCandidate) {
                bestCandidate = b;
                bestChar = entry.getKey();
            }
        }
        return bestChar;
    }

    /**
     * Internal helper method to add a character to the set and optionally trigger re-normalization.
     * This method is used by the constructor and the public addChar method.
     * @param c The character to add.
     * @param normalizeAfter If true, re-normalization of all character brightnesses is performed after adding.
     */
    private void addCharInternal(char c, boolean normalizeAfter) {
        double brightness = computeCharBrightness(c);
        charset.add(c);
        rawCharBrightness.put(c, brightness);
        if (normalizeAfter) {
            normalizeCharBrightness();
        }
    }

    /**
     * Recomputes the minimum and maximum brightness values from the current character set
     * and then linearly normalizes all character brightness values to a 0-1 range.
     * This method is crucial for adapting the character brightness scale when characters
     * are added or removed.
     * Assumes there are at least two characters with different brightness values if normalization
     * is needed (to avoid division by zero in the normalization formula).
     */
    private void normalizeCharBrightness() {
        if (charset.isEmpty()) return;
        double min = Collections.min(rawCharBrightness.values());
        double max = Collections.max(rawCharBrightness.values());
        currentMinBrightness = min;
        currentMaxBrightness = max;

        normalizedCharBrightness = new HashMap<>();
        for (Map.Entry<Character, Double> entry : rawCharBrightness.entrySet()) {
            double normalized = (max == min) ? 0.5 : (entry.getValue() - min) / (max - min);
            normalizedCharBrightness.put(entry.getKey(), normalized);
        }
    }

    /**
     * Computes the "raw" brightness of a single character.
     * This is calculated as the proportion of "white" pixels in its 16x16 boolean representation.
     * Assumes CharConverter.convertToBoolArray(char c) is available and returns a valid 2D boolean array.
     *
     * @param c The character for which to compute brightness.
     * @return The raw brightness value (0.0 to 1.0). Returns 0.0 if the character's pixel array is empty.
     */
    private double computeCharBrightness(char c) {
        boolean[][] pixels = CharConverter.convertToBoolArray(c);
        int total = 0, white = 0;
        for (boolean[] row : pixels) {
            for (boolean pixel : row) {
                total++;
                if (pixel) white++;
            }
        }
        return total == 0 ? 0.0 : (double) white / total;
    }
}
