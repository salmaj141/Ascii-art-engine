
package ascii_art;

import image.Image;
import image_char_matching.SubImgCharMatcher;
import ascii_output.ConsoleAsciiOutput;
import ascii_output.HtmlAsciiOutput;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * The Shell class provides an interactive command-line interface for the ASCII Art application.
 * It manages user input, program parameters such as image path, resolution, character set,
 * output method, and rounding method. It orchestrates the ASCII art generation process
 * by interacting with the {@code Image}, {@code SubImgCharMatcher}, and {@code AsciiArtAlgorithm} classes.
 * This class handles various user commands like 'exit', 'chars', 'add', 'remove', 'res',
 * 'output', 'round', and 'asciiArt', and provides appropriate error messages for invalid inputs.
 * @author salma,mariam
 */
public class Shell {
    // Constants for default program parameters, as specified in the exercise.
    private static final int DEFAULT_RES = 2;
    private static final String DEFAULT_ROUND = "abs";
    private static final String DEFAULT_OUTPUT = "console";
    private static final char[] DEFAULT_CHARS = "0123456789".toCharArray();
    private final Set<Character> charset = new TreeSet<>();
    // The SubImgCharMatcher instance responsible for managing the character set
    // and matching image brightness to characters.
    private final SubImgCharMatcher matcher;
    // The image object representing the input image.
    private final Image image;

    // The current resolution for ASCII art generation (characters per row).
    private int resolution;

    // The current output mode ("console" or "html").
    private String outputMode;

    // The current rounding method ("abs", "up", or "down").
    private String roundingMethod;

    /**
     * Constructs a Shell for managing the ASCII art interface.
     *
     * @param imagePath path to the input image file
     * @throws IOException if the image cannot be loaded
     */
    public Shell(String imagePath) throws IOException {
        this.image = new Image(imagePath);
        this.resolution = DEFAULT_RES;
        this.outputMode = DEFAULT_OUTPUT;
        this.roundingMethod = DEFAULT_ROUND;

        for (char c : DEFAULT_CHARS) {
            charset.add(c);
        }
        this.matcher = new SubImgCharMatcher(DEFAULT_CHARS);
    }

    /**
     * Runs the interactive shell loop, awaiting and executing user commands.
     */
    public void run() {
        System.out.println("Welcome to ASCII Art!");


        while (true) {
            try {
                System.out.print(">>> ");
                String line = KeyboardInput.readLine();
                if (line == null) continue;
                String[] tokens = line.trim().split("\s+");
                if (tokens.length == 0 || tokens[0].isEmpty()) continue;

                switch (tokens[0]) {
                    case "exit":
                        return;
                    case "chars":
                        printChars();
                        break;
                    case "add":
                        handleAdd(tokens);
                        break;
                    case "remove":
                        handleRemove(tokens);
                        break;
                    case "res":
                        handleRes(tokens);
                        break;
                    case "output":
                        handleOutput(tokens);
                        break;
                    case "round":
                        handleRound(tokens);
                        break;
                    case "asciiArt":
                        handleAsciiArt();
                        break;
                    default:
                        System.out.println("Did not execute due to incorrect command.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
        }
    }

    /**
     * Prints the characters currently used for ASCII art generation.
     */
    private void printChars() {
        if (charset.isEmpty()) return;
        for (char c : charset) {
            System.out.print(c + " ");
        }
        System.out.println();
    }

    /**
     * Handles the 'add' command to add characters to the charset.
     *
     * @param tokens command tokens
     */
    private void handleAdd(String[] tokens) {
        if (tokens.length < 2) {
            throw new IllegalArgumentException("Did not add due to incorrect format.");
        }

        String param = tokens[1];
        if (param.equals("all")) {
            for (char c = 32; c <= 126; c++) charset.add(c);
        } else if (param.equals("space")) {
            charset.add(' ');
        } else if (param.length() == 1) {
            char c = param.charAt(0);
            if (c >= 32 && c <= 126) charset.add(c);
            else throw new IllegalArgumentException("Did not add due to incorrect format.");
        } else if (param.length() == 3 && param.charAt(1) == '-') {
            char start = param.charAt(0);
            char end = param.charAt(2);
            if (start > end) {
                char temp = start;
                start = end;
                end = temp;
            }
            for (char c = start; c <= end; c++) {
                if (c >= 32 && c <= 126) charset.add(c);
                else throw new IllegalArgumentException("Did not add due to incorrect format.");
            }
        } else {
            throw new IllegalArgumentException("Did not add due to incorrect format.");
        }
    }

    /**
     * Handles the 'remove' command to remove characters from the charset.
     *
     * @param tokens command tokens
     */
    private void handleRemove(String[] tokens) {
        if (tokens.length < 2) {
            throw new IllegalArgumentException("Did not remove due to incorrect format.");
        }
        String param = tokens[1];
        if (param.equals("all")) {
            charset.clear();
        } else if (param.equals("space")) {
            charset.remove(' ');
        } else if (param.length() == 1) {
            charset.remove(param.charAt(0));
        } else if (param.length() == 3 && param.charAt(1) == '-') {
            char start = param.charAt(0);
            char end = param.charAt(2);
            if (start > end) {
                char temp = start;
                start = end;
                end = temp;
            }
            for (char c = start; c <= end; c++) {
                charset.remove(c);
            }
        } else {
            throw new IllegalArgumentException("Did not remove due to incorrect format.");
        }
    }

    /**
     * Handles the 'res' command for adjusting resolution.
     *
     * @param tokens command tokens
     */
    private void handleRes(String[] tokens) {
        int imgWidth = image.getWidth();
        int imgHeight = image.getHeight();
        int minRes = Math.max(1, imgWidth / imgHeight);

        if (tokens.length == 1) {
            System.out.println("Resolution set to " + resolution + ".");
        } else if (tokens[1].equals("up")) {
            if (resolution * 2 <= imgWidth) {
                resolution *= 2;
                System.out.println("Resolution set to " + resolution + ".");
            } else {
                System.out.println("Did not change resolution due to exceeding boundaries.");
            }
        } else if (tokens[1].equals("down")) {
            if (resolution / 2 >= minRes) {
                resolution /= 2;
                System.out.println("Resolution set to " + resolution + ".");
            } else {
                System.out.println("Did not change resolution due to exceeding boundaries.");
            }
        } else {
            throw new IllegalArgumentException("Did not change resolution due to incorrect format.");
        }
    }

    /**
     * Handles the 'output' command for switching between console and HTML output.
     *
     * @param tokens command tokens
     */
    private void handleOutput(String[] tokens) {
        if (tokens.length != 2 ||
                !(tokens[1].equals("console") || tokens[1].equals("html"))) {
            throw new IllegalArgumentException("Did not change output method due to incorrect format.");
        }
        outputMode = tokens[1];
    }

    /**
     * Handles the 'round' command for changing the rounding method.
     *
     * @param tokens command tokens
     */
    private void handleRound(String[] tokens) {
        if (tokens.length != 2 ||
                !(tokens[1].equals("abs") || tokens[1].equals("up") || tokens[1].equals("down"))) {
            throw new IllegalArgumentException("Did not change rounding method due to incorrect format.");
        }
        roundingMethod = tokens[1];
    }

    /**
     * Runs the ASCII art generation and displays the output based on current settings.
     */
    private void handleAsciiArt() {
        if (charset.size() < 2) {
            System.out.println("Did not execute. Charset is too small.");
            return;
        }

        try {
            AsciiArtAlgorithm algo = new AsciiArtAlgorithm(image, resolution,
                    new SubImgCharMatcher(charset.stream().map(Object::toString).collect(Collectors.joining()).toCharArray()),
                    roundingMethod);
            char[][] result = algo.run();

            if (outputMode.equals("console")) {
                new ConsoleAsciiOutput().out(result);
            } else {
                new HtmlAsciiOutput("out.html", "Courier New").out(result);
                System.out.println("Output written to out.html");
            }

        } catch (Exception e) {
            System.out.println("Failed to generate ASCII art: " + e.getMessage());
        }
    }

    /**
     * Entry point of the shell application.
     *
     * @param args expects a single argument: path to an image
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java ascii_art.Shell <image-path>");
            return;
        }

        try {
            Shell shell = new Shell(args[0]);
            shell.run();
        } catch (IOException e) {
            System.out.println("Error: Failed to load image. " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        }
    }
}
